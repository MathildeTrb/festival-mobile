//
//  EditorListIntent.swift
//  festival-mobile
//
//  Created by user188238 on 3/31/21.
//

import Foundation

class EditorListIntent {
    

}
