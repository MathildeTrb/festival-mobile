//
//  EditorListView.swift
//  festival-mobile
//
//  Created by user188238 on 3/30/21.
//

import SwiftUI

struct EditorListView: View {
    
    var body: some View {
        Text("Liste des éditeurs is coming")
    }
}

struct EditorListView_Previews: PreviewProvider {
    static var previews: some View {
        EditorListView()
    }
}
